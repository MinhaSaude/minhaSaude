export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyCzIqz0C86-2W57yo5wMNBD1BzU53KNKpA",
    authDomain: "lucky-display-182713.firebaseapp.com",
    databaseURL: "https://lucky-display-182713.firebaseio.com",
    projectId: "lucky-display-182713",
    storageBucket: "lucky-display-182713.appspot.com",
    messagingSenderId: "16912875697"
};