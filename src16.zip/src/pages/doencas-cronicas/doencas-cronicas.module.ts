import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DoencasCronicasPage } from './doencas-cronicas';

@NgModule({
  declarations: [
    DoencasCronicasPage,
  ],
  imports: [
    IonicPageModule.forChild(DoencasCronicasPage),
  ],
})
export class DoencasCronicasPageModule {}
