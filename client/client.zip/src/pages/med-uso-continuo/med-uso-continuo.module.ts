import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MedUsoContinuoPage } from './med-uso-continuo';

@NgModule({
  declarations: [
    MedUsoContinuoPage,
  ],
  imports: [
    IonicPageModule.forChild(MedUsoContinuoPage),
  ],
})
export class MedUsoContinuoPageModule {}
